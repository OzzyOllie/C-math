﻿using System;
class Program
{
    static void Main(string[] args)
    {
        Console.Write("Skriv inn det første tallet: ");
        string tall1Streng = Console.ReadLine();
        int tall1 = int.Parse(tall1Streng);
   
 // Be brukeren om å skrive inn det andre tallet
       
        Console.Write("Skriv inn det andre tallet: ");
        string tall2Streng = Console.ReadLine();
        int tall2 = int.Parse(tall2Streng);
        int sum = tall1 + tall2;
        Console.WriteLine($"Summen av tallene er: {sum}");
    }
}

